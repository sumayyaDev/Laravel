<?php $__env->startSection('content'); ?>
    <h3 class="page-title">Essay Questions</h3>


    <div class="panel panel-default">
        <div class="panel-heading">
            <?php echo app('translator')->getFromJson('quickadmin.list'); ?>

        </div>

        <div class="panel-body">
            <table class="table table-bordered table-striped <?php echo e(count($essays_questions) > 0 ? 'datatable' : ''); ?> dt-select">
                <thead>
                <tr>
                    <th style="text-align:center;"><input type="checkbox" id="select-all" /></th>
                    <th>Student</th>
                    <th>Topic</th>
                    <th> Exam </th>
                    <th> Date </th>
                    <th><?php echo app('translator')->getFromJson('quickadmin.questions.fields.question-text'); ?></th>
                    <th>&nbsp;</th>
                </tr>
                </thead>

                <tbody>
                <?php if(count($essays_questions) > 0): ?>

                    <?php $__currentLoopData = $essays_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e_question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($e_question->id); ?>">
                            <td></td>
                            <td><?php echo e($e_question->student_name); ?> </td>

                            <td><?php echo e($e_question->topic); ?></td>

                            <td><?php echo e($e_question->exam_type); ?></td>

                            <td><?php echo e($e_question->exam_date); ?></td>

                            <td><?php echo e($e_question->question); ?></td>
                            <td>
                                <a href="<?php echo e(route('exams.correct_create',[$e_question->id])); ?>" class="btn btn-xs btn-primary"><?php echo app('translator')->getFromJson('quickadmin.view'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7"><?php echo app('translator')->getFromJson('quickadmin.no_entries_in_table'); ?></td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        window.route_mass_crud_entries_destroy = '<?php echo e(route('questions.mass_destroy')); ?>';
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>