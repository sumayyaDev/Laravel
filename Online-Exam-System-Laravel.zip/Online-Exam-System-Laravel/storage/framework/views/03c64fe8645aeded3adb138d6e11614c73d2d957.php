<?php $__env->startSection('content'); ?>
    <h3 class="page-title"> Chose Your Subject</h3>
    <?php echo Form::open(['method' => 'POST', 'route' => ['registerSubject.register']]); ?>


    <div class="panel panel-default">
        <div class="panel-heading">
            Register
        </div>

        <div class="panel-body">
            <div class="row">
                <div class="col-xs-12 form-group">
                    <?php echo Form::label('topic_id', 'Subject', ['class' => 'control-label']); ?>

                    <?php echo Form::select('topic_id', $topics, old('topic_id'), ['class' => 'form-control']); ?>

                    <p class="help-block"></p>
                    <?php if($errors->has('topic_id')): ?>
                        <p class="help-block">
                            <?php echo e($errors->first('topic_id')); ?>

                        </p>
                    <?php endif; ?>
                </div>
            </div>



        </div>
    </div>

    <?php echo Form::submit("Register", ['class' => 'btn btn-danger']); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>