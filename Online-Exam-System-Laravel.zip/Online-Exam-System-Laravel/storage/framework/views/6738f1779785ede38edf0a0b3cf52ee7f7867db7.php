<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-10">
            <div class="panel panel-default">
                <div class="panel-heading">Welcome! </div>

                <?php if(Auth::user()->isAdmin()): ?>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6 text-center">
                                <h1><?php echo e($questions); ?></h1>
                                questions in our database
                            </div>
                            <div class="col-md-6 text-center">
                                <h1><?php echo e($users); ?></h1>
                                users registered
                            </div>
                        </div>
                    </div>
                <?php endif; ?>


                <?php if(Auth::user()->isStudent()): ?>

                    <div class="row" style="margin: 12px">
                        <div class="col-md-12" >
                            <div class="panel panel-default" >
                                <div class="panel-heading">Registered Subjects </div>


                                <div class="panel-body">
                                    <div class="row">
                                        <?php if(count($topics) > 0): ?>
                                            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div class="col-md-6 text-center">
                                                    <h1><?php echo e($topic->title); ?></h1>
                                                </div>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>


                    <div class="row" style="margin: 12px">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">Incoming Exams </div>

                                <div class="panel-body">
                                    <div class="row">


                                        <?php if(count($exams) > 0): ?>
                                            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($key % 3 == 0): ?>
                                    </div><br><br>
                                    <div class="row">
                                        <div class="col-md-4 text-center">
                                            <h4><b><?php echo e($exam->title); ?> :</b> <?php echo e($exam->exam_type); ?></h4>
                                            <h4><?php echo e($exam->exam_date); ?></h4>
                                        </div>
                                        <?php else: ?>

                                            <div class="col-md-4 text-center">
                                                <h4><b><?php echo e($exam->title); ?> :</b> <?php echo e($exam->exam_type); ?></h4>
                                                <h4><?php echo e($exam->exam_date); ?></h4>
                                            </div>
                                        <?php endif; ?>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>

                <?php endif; ?>


                <?php if(Auth::user()->isTeacher()): ?>
                    <div class="panel-body">
                        <div class="row">

                            <div class="col-md-4 text-center">
                                <h1><?php echo e($quizzes); ?></h1>
                                quizzes in Database
                            </div>

                            <div class="col-md-4 text-center">
                                <h1><?php echo e($quizzes); ?></h1>
                                Subjects in Database
                            </div>

                        </div>
                    </div>
                <?php endif; ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>