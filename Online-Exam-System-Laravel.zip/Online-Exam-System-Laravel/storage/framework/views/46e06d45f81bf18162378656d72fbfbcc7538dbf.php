<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-10">
            <div class="panel panel-default">
                <div class="panel-heading">Incoming Exams </div>

                <div class="panel-body">
                    <div class="row">


                        <?php if(count($exams) > 0): ?>
                            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($key % 3 == 0): ?>
                                    </div><br><br>
                                    <div class="row">
                                        <div class="col-md-4 text-center">
                                            <h4><b><?php echo e($exam->title); ?> :</b> <?php echo e($exam->exam_type); ?></h4>
                                            <h4><?php echo e($exam->exam_date); ?></h4>
                                            <a class="btn btn-success" href="<?php echo route('examwithid', ['exam_id'=>$exam->id]); ?>">Start Exam</a>
                                        </div>
                                 <?php else: ?>

                                        <div class="col-md-4 text-center">
                                            <h4><b><?php echo e($exam->title); ?> :</b> <?php echo e($exam->exam_type); ?></h4>
                                            <h4><?php echo e($exam->exam_date); ?></h4>
                                            <a class="btn btn-success" href="<?php echo route('examwithid', ['exam_id'=>$exam->id]); ?>">Start Exam</a>
                                        </div>
                                 <?php endif; ?>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                    </div>
                </div>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>