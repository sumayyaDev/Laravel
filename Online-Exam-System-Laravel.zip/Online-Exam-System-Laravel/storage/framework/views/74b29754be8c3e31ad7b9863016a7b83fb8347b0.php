<?php $request = app('Illuminate\Http\Request'); ?>
<div class="page-sidebar-wrapper">
    <div class="page-sidebar navbar-collapse collapse">
        <ul class="page-sidebar-menu"
            data-keep-expanded="false"
            data-auto-scroll="true"
            data-slide-speed="200">

            <?php if(Auth::user()->isStudent()): ?>

            <li class="<?php echo e($request->segment(1) == 'students' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('exams.student_index')); ?>">
                    <i class="fa fa-gears"></i>
                    <span class="title">My Exams</span>
                </a>
            </li>

            <li class="<?php echo e($request->segment(1) == 'results' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('results.index')); ?>">
                    <i class="fa fa-gears"></i>
                    <span class="title">My Results</span>
                </a>
            </li>

                <li class="<?php echo e($request->segment(1) == 'subjects' ? 'active' : ''); ?>">
                    <a href="#">
                        <i class="fa fa-gears"></i>
                        <span class="title"> My Subjects </span>
                        <span class="fa arrow"></span>
                    </a>

                    <ul class="sub-menu">

                        <li class="<?php echo e($request->segment(1) == 'subjects' ? 'active active-sub' : ''); ?>">
                            <a href="<?php echo e(route('SubjectsHome')); ?>">
                                <i class="fa fa-gears"></i>
                                <span class="title"> Registered Subjects </span>
                            </a>
                        </li>

                        <li class="<?php echo e($request->segment(1) == 'subjects' ? 'active active-sub' : ''); ?>">
                            <a href="<?php echo e(route('subjects.index')); ?>">
                                <i class="fa fa-gears"></i>
                                <span class="title"> Register For Subjects </span>
                            </a>
                        </li>


                    </ul>

                </li>




            <?php endif; ?>

            <?php if(Auth::user()->isTeacher()): ?>

                    <li class="<?php echo e($request->segment(1) == 'exams' ? 'active' : ''); ?>">
                        <a href="#">
                            <i class="fa fa-gears"></i>
                            <span class="title"> Exams </span>
                            <span class="fa arrow"></span>
                        </a>
                        <ul class="sub-menu">


                            <li class="<?php echo e($request->segment(1) == 'exams' ? 'active active-sub' : ''); ?>">
                                <a href="<?php echo e(route('exams.index')); ?>">
                                    <i class="fa fa-gears"></i>
                                    <span class="title"> Show Exams </span>
                                </a>
                            </li>

                            <li class="<?php echo e($request->segment(1) == 'exams' ? 'active active-sub' : ''); ?>">
                                <a href="<?php echo e(route('exams.create')); ?>">
                                    <i class="fa fa-gears"></i>
                                    <span class="title"> Add new Exam </span>
                                </a>
                            </li>

                            <li class="<?php echo e($request->segment(1) == 'exams' ? 'active active-sub' : ''); ?>">
                                <a href="<?php echo e(route('exams.correct_index')); ?>">
                                    <i class="fa fa-gears"></i>
                                    <span class="title"> Correct Exams </span>
                                </a>
                            </li>

                        </ul>




                    <li class="<?php echo e($request->segment(1) == 'topics' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('topics.index')); ?>">
                            <i class="fa fa-gears"></i>
                            <span class="title"><?php echo app('translator')->getFromJson('quickadmin.topics.title'); ?></span>
                        </a>
                    </li>
                    <li class="<?php echo e($request->segment(1) == 'questions' ? 'active' : ''); ?>">
                        <a href="#">
                            <i class="fa fa-gears"></i>
                            <span class="title"><?php echo app('translator')->getFromJson('quickadmin.questions.title'); ?></span>
                            <span class="fa arrow"></span>
                        </a>
                        <ul class="sub-menu">

                            <li class="<?php echo e($request->segment(1) == 'users' ? 'active active-sub' : ''); ?>">
                                <a href="<?php echo e(route('questions.create')); ?>">
                                    <i class="fa fa-plus"></i>
                                    <span class="title">
                                <?php echo app('translator')->getFromJson('quickadmin.questions.add-new-MC'); ?>
                            </span>
                                </a>
                            </li>

                            <li class="<?php echo e($request->segment(1) == 'users' ? 'active active-sub' : ''); ?>">
                                <a href="<?php echo e(route('QuestionEssay.essay_create')); ?>">
                                    <i class="fa fa-plus"></i>
                                    <span class="title">
                                <?php echo app('translator')->getFromJson('quickadmin.questions.add-new-essay'); ?>
                            </span>
                                </a>
                            </li>

                            <li class="<?php echo e($request->segment(1) == 'roles' ? 'active active-sub' : ''); ?>">
                                <a href="<?php echo e(route('questions.index')); ?>">
                                    <i class="fa fa-list"></i>
                                    <span class="title">
                                    <?php echo app('translator')->getFromJson('quickadmin.questions.title'); ?>
                            </span>
                                </a>
                            </li>



                        </ul>





                    </li>
                    <li class="<?php echo e($request->segment(1) == 'questions_options' ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('questions_options.index')); ?>">
                            <i class="fa fa-gears"></i>
                            <span class="title"><?php echo app('translator')->getFromJson('quickadmin.questions-options.title'); ?></span>
                        </a>
                    </li>

            <?php endif; ?>

            <?php if(Auth::user()->isAdmin()): ?>
            <li>
                <a href="#">
                    <i class="fa fa-users"></i>
                    <span class="title"><?php echo app('translator')->getFromJson('quickadmin.user-management.title'); ?></span>
                    <span class="fa arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="<?php echo e($request->segment(1) == 'roles' ? 'active active-sub' : ''); ?>">
                        <a href="<?php echo e(route('roles.index')); ?>">
                            <i class="fa fa-briefcase"></i>
                            <span class="title">
                                <?php echo app('translator')->getFromJson('quickadmin.roles.title'); ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php echo e($request->segment(1) == 'users' ? 'active active-sub' : ''); ?>">
                        <a href="<?php echo e(route('users.index')); ?>">
                            <i class="fa fa-user"></i>
                            <span class="title">
                                <?php echo app('translator')->getFromJson('quickadmin.users.title'); ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php echo e($request->segment(1) == 'user_actions' ? 'active active-sub' : ''); ?>">
                        <a href="<?php echo e(route('user_actions.index')); ?>">
                            <i class="fa fa-th-list"></i>
                            <span class="title">
                                <?php echo app('translator')->getFromJson('quickadmin.user-actions.title'); ?>
                            </span>
                        </a>
                    </li>
                </ul>
            </li>
            <?php endif; ?>
            <li>
                <a href="#logout" onclick="$('#logout').submit();">
                    <i class="fa fa-arrow-left"></i>
                    <span class="title"><?php echo app('translator')->getFromJson('quickadmin.logout'); ?></span>
                </a>
            </li>
        </ul>


    </div>
</div>
<?php echo Form::open(['route' => 'auth.logout', 'style' => 'display:none;', 'id' => 'logout']); ?>

<button type="submit"><?php echo app('translator')->getFromJson('quickadmin.logout'); ?></button>
<?php echo Form::close(); ?>

